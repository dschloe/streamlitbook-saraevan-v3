# 은행 마케팅 캠페인 예측 시스템 프로젝트 정의서

## 1. 프로젝트 개요
포르투갈 은행의 마케팅 캠페인 데이터를 활용하여 고객의 정기 예금 가입 여부를 예측하는 머신러닝 시스템 개발

## 2. 데이터셋 구성
### 2.1 기본 데이터셋 (data/bank/)
- bank.csv: 4,521개 샘플 (전체 데이터의 10%)
- bank-full.csv: 45,211개 샘플 (2008년 5월 ~ 2010년 11월)

### 2.2 추가 데이터셋 (data/bank-additional/)
- bank-additional.csv: 4,119개 샘플 (전체 데이터의 10%)
- bank-additional-full.csv: 41,188개 샘플
- 사회경제적 지표 5개 추가 포함

## 3. 기술 스택
### 3.1 백엔드
- FastAPI
  - RESTful API 구현
  - 비동기 처리 지원
  - OpenAPI (Swagger) 문서 자동 생성
  - 요청/응답 데이터 검증

### 3.2 프론트엔드
- Streamlit
  - 데이터 시각화 대시보드
  - 실시간 예측 인터페이스
  - 대화형 분석 도구
  - 머신러닝 모델 성능 모니터링

### 3.3 컨테이너화
- Docker
  ```dockerfile
  FROM python:3.9-slim
  WORKDIR /app
  COPY requirements.txt .
  RUN pip install --no-cache-dir -r requirements.txt
  COPY . .
  ```

- Docker Compose
  ```yaml
  version: '3'
  services:
    backend:
      build: 
        context: .
        dockerfile: docker/Dockerfile
      ports:
        - "8000:8000"
    frontend:
      build: .
      ports:
        - "8501:8501"
      depends_on:
        - backend
  ```

### 3.4 데이터 처리 및 머신러닝
- pandas, numpy: 데이터 전처리
- scikit-learn: 모델 개발
- plotly: 데이터 시각화

## 4. 프로젝트 구조
```
.
├── data/                # 데이터 파일
├── notebooks/           # 분석 노트북
├── src/
│   ├── frontend/       # Streamlit 앱
│   ├── backend/        # FastAPI 서버
│   └── models/         # ML 모델 관련 코드
├── tests/              # 테스트 코드
└── docker/             # Docker 설정
```

## 5. 개발 목표
1. 데이터 전처리 파이프라인 구축
2. 머신러닝 모델 개발 및 최적화
3. REST API 서버 구현
4. 웹 기반 대시보드 개발
5. 도커라이즈된 배포 환경 구성

## 6. 평가 지표
- 정확도 (Accuracy)
- 정밀도 (Precision)
- 재현율 (Recall)
- F1 점수
- ROC-AUC 점수

## 7. 산출물
- 학습된 머신러닝 모델
- API 서버
- 웹 대시보드
- 모델 성능 평가 보고서
- 기술 문서

## 8. 일정 계획
1. 데이터 탐색 및 전처리
2. 모델 개발 및 학습
3. API 서버 개발
4. 프론트엔드 개발
5. 통합 테스트
6. 배포 및 문서화

## 9. 개발 환경 설정
```bash
# 가상환경 생성
python -m venv venv
source venv/bin/activate

# 의존성 설치
pip install -r requirements.txt

# 개발 서버 실행
uvicorn src.backend.main:app --reload  # 백엔드
streamlit run src.frontend.app.py      # 프론트엔드

# Docker 실행
docker-compose up
