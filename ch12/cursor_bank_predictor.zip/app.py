import streamlit as st
import json
import pandas as pd
import joblib
from typing import Dict

# 페이지 설정
st.set_page_config(
    page_title="Bank Marketing Predictor",
    page_icon="🏦",
    layout="wide"
)

def load_models():
    """모델과 메타데이터 로드"""
    try:
        # 모델 로드
        rf_model_info = joblib.load('models/random_forest_model.joblib')
        xgb_model_info = joblib.load('models/xgboost_model.joblib')
        
        # 메타데이터 로드
        with open('models/model_metadata.json', 'r') as f:
            metadata = json.load(f)
            
        return rf_model_info, xgb_model_info, metadata
    except Exception as e:
        st.error(f"모델 로드 실패: {str(e)}")
        return None, None, None

def preprocess_data(df: pd.DataFrame, selected_features):
    """데이터 전처리"""
    df_encoded = df.copy()
    result_df = pd.DataFrame(index=df_encoded.index)
    
    # 수치형 변수 처리
    numeric_features = ['age', 'balance', 'day', 'duration', 'campaign', 'pdays', 'previous']
    for feature in numeric_features:
        if feature in selected_features:
            result_df[feature] = df_encoded[feature]
    
    # 범주형 변수 처리
    # marital
    result_df['marital_divorced'] = (df_encoded['marital'] == 'divorced').astype(int)
    result_df['marital_married'] = (df_encoded['marital'] == 'married').astype(int)
    result_df['marital_single'] = (df_encoded['marital'] == 'single').astype(int)
    
    # housing
    result_df['housing_no'] = (df_encoded['housing'] == 'no').astype(int)
    result_df['housing_yes'] = (df_encoded['housing'] == 'yes').astype(int)
    
    # loan
    result_df['loan_no'] = (df_encoded['loan'] == 'no').astype(int)
    result_df['loan_yes'] = (df_encoded['loan'] == 'yes').astype(int)
    
    # month
    months = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']
    for month in months:
        result_df[f'month_{month}'] = (df_encoded['month'] == month).astype(int)
    
    # poutcome
    result_df['poutcome_failure'] = (df_encoded['poutcome'] == 'failure').astype(int)
    result_df['poutcome_other'] = (df_encoded['poutcome'] == 'other').astype(int)
    result_df['poutcome_success'] = (df_encoded['poutcome'] == 'success').astype(int)
    result_df['poutcome_unknown'] = (df_encoded['poutcome'] == 'unknown').astype(int)
    
    # job
    jobs = ['admin.', 'blue-collar', 'entrepreneur', 'housemaid', 'management',
            'retired', 'self-employed', 'services', 'student', 'technician',
            'unemployed', 'unknown']
    for job in jobs:
        result_df[f'job_{job}'] = (df_encoded['job'] == job).astype(int)
    
    return result_df[selected_features]

def main():
    st.title("🏦 Bank Marketing Predictor")
    
    # 모델 로드
    rf_model_info, xgb_model_info, metadata = load_models()
    
    if not all([rf_model_info, xgb_model_info, metadata]):
        st.error("모델을 로드할 수 없습니다.")
        return
    
    # 사이드바에 모델 정보 표시
    st.sidebar.header("모델 정보")
    for model in ["random_forest", "xgboost"]:
        st.sidebar.subheader(f"{model.upper()} 성능")
        metrics = metadata[model]["metrics"]
        for metric, value in metrics.items():
            st.sidebar.metric(metric.upper(), f"{value:.3f}")
    
    # 메인 화면에 입력 폼
    st.header("고객 정보 입력")
    
    col1, col2 = st.columns(2)
    
    with col1:
        age = st.number_input("나이", min_value=18, max_value=100, value=35)
        job = st.selectbox(
            "직업",
            ["admin.", "blue-collar", "entrepreneur", "housemaid", "management",
             "retired", "self-employed", "services", "student", "technician",
             "unemployed", "unknown"]
        )
        marital = st.selectbox("결혼 상태", ["married", "single", "divorced"])
        education = st.selectbox("교육 수준", ["primary", "secondary", "tertiary", "unknown"])
        default = st.selectbox("신용불량 여부", ["no", "yes"])
        balance = st.number_input("계좌 잔액", value=0)
        housing = st.selectbox("주택대출 여부", ["no", "yes"])
        loan = st.selectbox("개인대출 여부", ["no", "yes"])
    
    with col2:
        contact = st.selectbox("연락 수단", ["cellular", "telephone", "unknown"])
        day = st.number_input("마지막 연락 일자", min_value=1, max_value=31, value=15)
        month = st.selectbox(
            "마지막 연락 월",
            ["jan", "feb", "mar", "apr", "may", "jun", 
             "jul", "aug", "sep", "oct", "nov", "dec"]
        )
        duration = st.number_input("마지막 통화 시간(초)", min_value=0, value=258)
        campaign = st.number_input("캠페인 연락 횟수", min_value=1, value=1)
        pdays = st.number_input("이전 캠페인 후 경과일", value=999)
        previous = st.number_input("이전 캠페인 연락 횟수", min_value=0, value=0)
        poutcome = st.selectbox("이전 캠페인 결과", ["unknown", "failure", "success", "other"])

    if st.button("예측하기"):
        # 입력 데이터 처리
        input_data = pd.DataFrame([{
            "age": age, "job": job, "marital": marital, "education": education,
            "default": default, "balance": balance, "housing": housing, "loan": loan,
            "contact": contact, "day": day, "month": month, "duration": duration,
            "campaign": campaign, "pdays": pdays, "previous": previous, "poutcome": poutcome
        }])
        
        # 각 모델용 데이터 전처리
        rf_processed = preprocess_data(input_data, rf_model_info['feature_names'])
        xgb_processed = preprocess_data(input_data, xgb_model_info['feature_names'])
        
        # 예측 수행
        rf_prob = rf_model_info['model'].predict_proba(rf_processed)[0][1]
        xgb_prob = xgb_model_info['model'].predict_proba(xgb_processed)[0][1]
        
        # 앙상블 확률 계산
        ensemble_prob = (rf_prob + xgb_prob) / 2
        
        # 결과 표시
        st.header("예측 결과")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric(
                "Random Forest",
                "가입" if rf_prob >= 0.5 else "미가입",
                f"{rf_prob:.1%}"
            )
        
        with col2:
            st.metric(
                "XGBoost",
                "가입" if xgb_prob >= 0.5 else "미가입",
                f"{xgb_prob:.1%}"
            )
        
        with col3:
            st.metric(
                "앙상블 예측 확률",
                f"{ensemble_prob:.1%}"
            )

if __name__ == "__main__":
    main() 